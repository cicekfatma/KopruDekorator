public interface ICepTelefonu {
    public String telefonDetay();
}
