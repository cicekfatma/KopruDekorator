public class Main {
    public static void main(String[] args){
        ICepTelefonu cepTelefonu1 = new Telefon();
        System.out.println(cepTelefonu1.telefonDetay());
        cepTelefonu1 = new TelefonKilifi(cepTelefonu1);
        System.out.println(cepTelefonu1.telefonDetay());
        cepTelefonu1 = new Kulaklik(cepTelefonu1);
        System.out.println(cepTelefonu1.telefonDetay());
        ICepTelefonu cepTelefonu2 =new Telefon();
        cepTelefonu2= new Kulaklik(cepTelefonu2);
        System.out.println(cepTelefonu2.telefonDetay());
    }
}
