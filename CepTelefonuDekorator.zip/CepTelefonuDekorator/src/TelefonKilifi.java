public class TelefonKilifi extends CepTelefonuEklentileri{
    TelefonKilifi(ICepTelefonu cepTelefonu){
        super(cepTelefonu);
    }
    @Override
    public String telefonDetay(){
        return eklentiliTelefon.telefonDetay()+"na kılıf eklendi";
    }
}
