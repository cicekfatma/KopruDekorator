public class Telefon implements ICepTelefonu{
    @Override
    public String telefonDetay(){
        return "Cep Telefonu";
    }
}
