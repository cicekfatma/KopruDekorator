public class CepTelefonuEklentileri implements ICepTelefonu{
    ICepTelefonu eklentiliTelefon;
    CepTelefonuEklentileri(ICepTelefonu cepTelefonu){
        this.eklentiliTelefon=cepTelefonu;
    }
    @Override
    public String telefonDetay(){
        return eklentiliTelefon.telefonDetay();
    }
}
