public class Kulaklik extends CepTelefonuEklentileri{
    Kulaklik(ICepTelefonu cepTelefonu){
        super(cepTelefonu);
    }
    @Override
    public String telefonDetay(){
        return eklentiliTelefon.telefonDetay()+"una Kulaklık eklendi";
    }
}
